# Plots

This folder contains movies that show the trajectory of qubits in several conditions.

* If H_1 is unspecified, H_1 / w_0 = 0.4
* Prefix lf/rf means lab frame/rotating frame respectively
* The kind of drive is specified by pd/cd meaning perpendicular drive/circular drive respectively
